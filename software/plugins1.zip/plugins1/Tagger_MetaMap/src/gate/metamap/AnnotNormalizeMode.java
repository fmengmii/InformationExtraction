/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gate.metamap;

/**
 *
 * @author philipgooch
 */
public enum AnnotNormalizeMode {
    None, LeadingDeterminer, AllDeterminers
}
