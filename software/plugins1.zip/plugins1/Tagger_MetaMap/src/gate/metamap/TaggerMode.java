/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gate.metamap;

/**
 *
 * @author philipgooch
 */
public enum TaggerMode {
    FirstOccurrenceOnly, CoReference, AllOccurrences
}
