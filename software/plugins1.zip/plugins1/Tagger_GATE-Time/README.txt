This plugin includes HeidelTime developed by Heidelberg University which is
available under the GNU GPL. For more details see https://github.com/HeidelTime/heideltime