This plugin makes a number of libraries developed by the Stanford NLP group
available within GATE. For more details see http://nlp.stanford.edu/software/